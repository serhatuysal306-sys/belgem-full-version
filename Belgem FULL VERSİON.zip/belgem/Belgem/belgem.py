# -*- coding: utf-8 -*-
"""Belgem - ücretsiz DOCX okuyucu ve düzenleyici (PyQt6 + python-docx)."""
import os
import sys
import io
import html
import json
import traceback

from PyQt6.QtCore import Qt, QUrl, QSize, QSizeF, QTimer, QBuffer, QIODevice, QMarginsF, QPointF, pyqtSignal, QThread
from PyQt6.QtGui import QPainter, QPen, QDesktopServices, QPixmap
from PyQt6.QtGui import (QAction, QColor, QFont, QImage, QKeySequence, QTextCharFormat,
                         QTextCursor, QTextDocument, QTextImageFormat, QTextListFormat,
                         QTextBlockFormat, QTextFrameFormat, QTextLength, QTextTableFormat,
                         QTextFormat, QPageSize, QPageLayout, QIcon)
from PyQt6.QtPrintSupport import QPrinter
from PyQt6.QtWidgets import (QApplication, QMainWindow, QTextEdit, QToolBar, QFontComboBox,
                             QComboBox, QFileDialog, QMessageBox, QColorDialog, QDialog,
                             QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QCheckBox,
                             QLabel, QSpinBox, QFormLayout, QDialogButtonBox, QInputDialog, QDoubleSpinBox,
                             QListWidget, QListWidgetItem, QDockWidget, QTextBrowser, QWidget,
                             QToolButton, QScrollArea, QFrame)
from PyQt6.QtPrintSupport import QPrintDialog

APP = "Belgem"
DEFAULT_FONT = "Calibri"
DEFAULT_SIZE = 11
HEAD_SIZES = {1: 20, 2: 16, 3: 14, 4: 13}
PAPER = {"A4": (210, 297), "A5": (148, 210), "A3": (297, 420), "B5": (176, 250),
         "Letter": (215.9, 279.4), "Legal": (215.9, 355.6)}
BREAK_PROP = 0x100001
BREAK_TEXT = "\u2500\u2500\u2500\u2500\u2500  Sayfa sonu  \u2500\u2500\u2500\u2500\u2500"


def theme_css(bw):
    """Aray\u00fcz renkleri. bw=True: siyah beyaz, bw=False: renkli (varsay\u0131lan)."""
    if bw:
        c = dict(win="#ffffff", bar="#ffffff", line="#000000", txt="#000000", hov="#e6e6e6",
                 on="#000000", on_txt="#ffffff", ed="#8c8c8c", sel="#000000", sel_txt="#ffffff")
    else:
        c = dict(win="#e9ecef", bar="#f8f9fa", line="#d0d4d9", txt="#111111", hov="#e2e6ea",
                 on="#cfe2ff", on_txt="#111111", ed="#d5d9de", sel="#9ec5fe", sel_txt="#000000")
    c["app"] = ("QMainWindow{background:%(win)s;} QWidget{color:%(txt)s;font-size:13px;}"
                "QToolBar{background:%(bar)s;border:0;border-bottom:2px solid %(line)s;spacing:4px;padding:4px;}"
                "QToolButton{padding:6px 10px;border-radius:4px;font-size:14px;font-weight:600;color:%(txt)s;}"
                "QToolButton:hover{background:%(hov)s;}"
                "QToolButton:checked{background:%(on)s;color:%(on_txt)s;}"
                "QComboBox,QFontComboBox,QSpinBox{font-size:14px;padding:4px;border:1px solid %(line)s;"
                "background:#ffffff;color:%(txt)s;}"
                "QStatusBar{background:%(bar)s;border-top:1px solid %(line)s;font-size:14px;}"
                "QMenuBar{font-size:14px;} QMenu{font-size:14px;}"
                "QDialog{background:%(win)s;}"
                "QPushButton{padding:6px 12px;font-size:14px;border:1px solid %(line)s;border-radius:4px;"
                "background:#ffffff;color:%(txt)s;}") % c
    c["ed_css"] = ("QTextEdit{background:%(ed)s;color:#000;border:none;"
                   "selection-background-color:%(sel)s;selection-color:%(sel_txt)s;}") % c
    return c


CONFIG_FILE = "ayar.json"


def load_cfg():
    try:
        with open(os.path.join(data_dir(), CONFIG_FILE), encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def save_cfg(cfg):
    try:
        with open(os.path.join(data_dir(), CONFIG_FILE), "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False)
    except Exception:
        pass


def load_bw():
    return bool(load_cfg().get("siyah_beyaz"))


def save_bw(bw):
    cfg = load_cfg()
    cfg["siyah_beyaz"] = bw
    save_cfg(cfg)


# --------------------------------------------------------------------------
#  Hazır CV kalıpları (5 dil)
# --------------------------------------------------------------------------
LANG_NAMES = [("tr", "Türkçe"), ("en", "English"), ("de", "Deutsch"), ("fr", "Français"), ("es", "Español")]
GEMINI_MODEL = "gemini-2.5-flash"
LANG = load_cfg().get("dil") or "tr"
EN = {
    "Yeni": "New", "Aç": "Open", "Kaydet": "Save", "Farklı kaydet": "Save as",
    "PDF olarak kaydet": "Save as PDF", "Geri al": "Undo", "Yinele": "Redo",
    "Bul / Değiştir": "Find / Replace", "Yazdır": "Print", "Sayfa yapısı": "Page setup",
    "Siyah beyaz": "Black & white", "Siyah beyaz görünüm aç/kapat": "Toggle black & white view",
    "Kalın (Ctrl+B)": "Bold (Ctrl+B)", "Eğik (Ctrl+I)": "Italic (Ctrl+I)",
    "Altı çizili (Ctrl+U)": "Underline (Ctrl+U)", "Üstü çizili": "Strikethrough",
    "Renk": "Color", "Yazı rengi": "Text color", "Vurgu": "Highlight",
    "Sarı vurgu aç/kapat": "Toggle yellow highlight", "Sol": "Left", "Orta": "Center",
    "Sağ": "Right", "İki yana": "Justify", "• Liste": "• List", "1. Liste": "1. List",
    "Tablo": "Table", "Resim": "Image", "◀ Girinti": "◀ Outdent", "Girinti ▶": "Indent ▶",
    "Girintiyi azalt": "Decrease indent", "Girintiyi artır": "Increase indent",
    "Üst simge": "Superscript", "Alt simge": "Subscript", "Biçimi temizle": "Clear format",
    "Bağlantı": "Link", "Bağlantı ekle (Ctrl+K)": "Insert link (Ctrl+K)",
    "Sayfa sonu": "Page break", "Sayfa sonu ekle (Ctrl+Enter)": "Insert page break (Ctrl+Enter)",
    "Tümünü seç": "Select all", "Dosya": "File", "Biçim": "Format", "Ek": "More", "Düzen": "Edit",
    "Sayfa": "Page", "Görünüm": "View", "Yardım": "Help", "Sayfa sonu ekle": "Insert page break",
    "Ana sayfa (CV kalıpları)": "Home (CV templates)", "Ayarlar": "Settings", "Çıkış": "Exit",
    "Belgem hakkında": "About Belgem",
    "Belgem — Ana sayfa": "Belgem — Home",
    "Yeni bir belge başlat": "Start a new document", "Belgelerde ara...": "Search documents...",
    "Klasik": "Classic", "Modern": "Modern", "Minimal": "Minimal",
    "Son belgeler": "Recent documents", "Henüz belge yok": "No documents yet",
    "Hazır CV kalıbı seç, son belgelerini aç veya boş belgeyle başla.":
        "Pick a ready CV template, open a recent document or start blank.",
    "Ara: cv, türkçe, english, deutsch, dosya adı...": "Search: cv, english, deutsch, file name...",
    "Tüm diller": "All languages", "Boş belge": "Blank document", "Dosya seç...": "Choose file...",
    "Seçileni aç": "Open selected", "Son açılan": "Recent",
    "Dil:": "Language:", "Yapay zeka adı:": "AI assistant name:", "Gemini API anahtarı:": "Gemini API key:",
    "Anahtarı al: aistudio.google.com/app/apikey  (anahtar bu bilgisayarda saklanır)":
        "Get a key at aistudio.google.com/app/apikey (stored on this computer only)",
    "Yapay zeka yardımcısını aç/kapat": "Show / hide AI assistant",
    "Bir soru yaz... (Enter)": "Type a question... (Enter)",
    "Açık belgeyi de gönder": "Also send the open document", "Gönder": "Send",
    "Sen": "You", "Yanıt bekleniyor...": "Waiting for reply...",
    "Önce Dosya → Ayarlar bölümünden Gemini API anahtarını gir.":
        "First enter your Gemini API key under File → Settings.",
    "Dil değişikliği uygulamayı yeniden açınca tam görünür.":
        "The language change fully applies after restarting the app.",
}


def T(s):
    """Arayüz metni: Türkçe ise olduğu gibi, değilse İngilizce (yoksa Türkçe)."""
    if LANG == "tr":
        return s
    return EN.get(s, s)


def ask_gemini(key, question, context):
    import urllib.request
    url = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent" % GEMINI_MODEL
    text = question if not context else (
        "Aşağıdaki belge bağlamında yanıtla.\n\nBELGE:\n%s\n\nSORU: %s" % (context, question))
    body = {"contents": [{"parts": [{"text": text}]}]}
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), method="POST",
                                 headers={"Content-Type": "application/json", "x-goog-api-key": key})
    with urllib.request.urlopen(req, timeout=60) as r:
        d = json.loads(r.read().decode("utf-8"))
    return d["candidates"][0]["content"]["parts"][0]["text"]


CV_LANGS = {
    "tr": dict(name="Türkçe", cv="Özgeçmiş", contact="Telefon · E-posta · Şehir",
               profile="Profil", summary="Uzmanlık alanınızı, güçlü yönlerinizi ve kariyer hedefinizi kısaca yazın.",
               exp="İş Deneyimi", job="Pozisyon", company="Şirket adı", dates="Ocak 2022 – Aralık 2025",
               task="Sorumluluklarınızı ve elde ettiğiniz sonuçları (mümkünse ölçülebilir) yazın.",
               edu="Eğitim", degree="Bölüm / derece", school="Okul adı",
               skills="Beceriler", skills_text="Beceri 1 · Beceri 2 · Beceri 3",
               langs="Yabancı Diller", lang_text="İngilizce — İleri · Almanca — Orta",
               proj="Projeler", pname="Proje adı", ptask="Kısa açıklama ve kullanılan teknolojiler."),
    "en": dict(name="English", cv="Resume", contact="Phone · Email · City",
               profile="Profile", summary="Briefly describe your expertise, key strengths and career goal.",
               exp="Work Experience", job="Job title", company="Company name", dates="Jan 2022 – Dec 2025",
               task="Describe your responsibilities and measurable achievements.",
               edu="Education", degree="Degree / major", school="University name",
               skills="Skills", skills_text="Skill 1 · Skill 2 · Skill 3",
               langs="Languages", lang_text="English — Fluent · German — Intermediate",
               proj="Projects", pname="Project name", ptask="Short description and technologies used."),
    "de": dict(name="Deutsch", cv="Lebenslauf", contact="Telefon · E-Mail · Ort",
               profile="Profil", summary="Fassen Sie Ihre Fachkompetenz, Stärken und Ihr Karriereziel kurz zusammen.",
               exp="Berufserfahrung", job="Position", company="Firmenname", dates="Jan. 2022 – Dez. 2025",
               task="Beschreiben Sie Ihre Aufgaben und messbaren Erfolge.",
               edu="Ausbildung", degree="Studiengang / Abschluss", school="Hochschule",
               skills="Kenntnisse", skills_text="Kenntnis 1 · Kenntnis 2 · Kenntnis 3",
               langs="Sprachen", lang_text="Englisch — Fließend · Türkisch — Muttersprache",
               proj="Projekte", pname="Projektname", ptask="Kurze Beschreibung und verwendete Technologien."),
    "fr": dict(name="Français", cv="CV", contact="Téléphone · E-mail · Ville",
               profile="Profil", summary="Résumez brièvement votre expertise, vos atouts et votre objectif professionnel.",
               exp="Expérience professionnelle", job="Intitulé du poste", company="Nom de l'entreprise",
               dates="Janv. 2022 – Déc. 2025",
               task="Décrivez vos responsabilités et vos réalisations mesurables.",
               edu="Formation", degree="Diplôme / spécialité", school="Nom de l'établissement",
               skills="Compétences", skills_text="Compétence 1 · Compétence 2 · Compétence 3",
               langs="Langues", lang_text="Anglais — Courant · Turc — Langue maternelle",
               proj="Projets", pname="Nom du projet", ptask="Brève description et technologies utilisées."),
    "es": dict(name="Español", cv="Currículum", contact="Teléfono · Correo · Ciudad",
               profile="Perfil", summary="Describa brevemente su experiencia, sus fortalezas y su objetivo profesional.",
               exp="Experiencia laboral", job="Puesto", company="Nombre de la empresa",
               dates="Ene. 2022 – Dic. 2025",
               task="Describa sus responsabilidades y logros medibles.",
               edu="Formación", degree="Título / especialidad", school="Nombre de la institución",
               skills="Habilidades", skills_text="Habilidad 1 · Habilidad 2 · Habilidad 3",
               langs="Idiomas", lang_text="Inglés — Avanzado · Turco — Nativo",
               proj="Proyectos", pname="Nombre del proyecto", ptask="Breve descripción y tecnologías utilizadas."),
}


def build_cv_html(L):
    def h(t):
        return "<h2>%s</h2>" % t

    def p(t):
        return "<p>%s</p>" % t
    return ("<h1>Ad Soyad</h1>" + p(L["contact"]) +
            h(L["profile"]) + p(L["summary"]) +
            h(L["exp"]) + p("<b>%s</b> — %s" % (L["job"], L["company"])) + p(L["dates"]) + p(L["task"]) +
            h(L["edu"]) + p("<b>%s</b> — %s" % (L["degree"], L["school"])) + p(L["dates"]) +
            h(L["skills"]) + p(L["skills_text"]) +
            h(L["langs"]) + p(L["lang_text"]) +
            h(L["proj"]) + p("<b>%s</b>" % L["pname"]) + p(L["ptask"]))


CV_TEMPLATES = []
for _code, _L in CV_LANGS.items():
    CV_TEMPLATES.append({
        "id": _code,
        "lang_code": _code,
        "title": _L["cv"] + " — " + _L["name"],
        "search": (_L["cv"] + " " + _L["name"] + " cv resume lebenslauf curriculum " + _code).lower(),
        "html": build_cv_html(_L),
    })


def default_page():
    return {"w": 210.0, "h": 297.0, "m": [2.54, 2.54, 2.54, 2.54], "header": "", "footer": "",
            "numbers": False}


def paper_name(w, h):
    for n, (a, b) in PAPER.items():
        if (abs(w - a) < 1.5 and abs(h - b) < 1.5) or (abs(w - b) < 1.5 and abs(h - a) < 1.5):
            return n + (" yatay" if w > h else "")
    return "Özel"


def mm_px(mm):
    return mm / 25.4 * 96.0


BULLET = "bullet"
NUMBER = "number"


def data_dir():
    base = os.environ.get("APPDATA") or os.path.expanduser("~/.config")
    p = os.path.join(base, APP)
    os.makedirs(p, exist_ok=True)
    return p


# --------------------------------------------------------------------------
#  DOCX  ->  QTextDocument
# --------------------------------------------------------------------------
def _qcolor_from_run(run):
    try:
        c = run.font.color
        if c is not None and c.rgb is not None:
            return QColor("#" + str(c.rgb))
    except Exception:
        pass
    return None


def _run_format(run, heading=0):
    f = QTextCharFormat()
    try:
        if run.bold or heading:
            f.setFontWeight(QFont.Weight.Bold)
        if run.italic:
            f.setFontItalic(True)
        if run.underline:
            f.setFontUnderline(True)
        if run.font.strike:
            f.setFontStrikeOut(True)
        if run.font.name:
            f.setFontFamilies([run.font.name])
        if heading:
            f.setFontPointSize(HEAD_SIZES.get(heading, 13))
        elif run.font.size:
            f.setFontPointSize(run.font.size.pt)
        if run.font.superscript:
            f.setVerticalAlignment(QTextCharFormat.VerticalAlignment.AlignSuperScript)
        elif run.font.subscript:
            f.setVerticalAlignment(QTextCharFormat.VerticalAlignment.AlignSubScript)
        col = _qcolor_from_run(run)
        if col is not None:
            f.setForeground(col)
        if run.font.highlight_color is not None:
            f.setBackground(QColor("#ffff00"))
    except Exception:
        pass
    return f


class Loader:
    def __init__(self, doc: QTextDocument):
        self.doc = doc
        self.img_n = 0

    def _heading_level(self, p):
        try:
            name = (p.style.name or "").lower()
        except Exception:
            return 0
        if name == "title":
            return 1
        if name.startswith("heading "):
            try:
                return max(1, min(4, int(name.split()[1])))
            except Exception:
                return 0
        return 0

    def _list_kind(self, p):
        try:
            name = (p.style.name or "").lower()
        except Exception:
            name = ""
        if "list number" in name or "numbered" in name:
            return NUMBER
        if "list bullet" in name or name.startswith("list"):
            return BULLET
        try:
            pPr = p._p.pPr
            if pPr is not None and pPr.numPr is not None:
                return BULLET
        except Exception:
            pass
        return None

    def _insert_image(self, cur, run_el, part):
        from docx.oxml.ns import qn
        blips = run_el.findall(".//" + qn("a:blip"))
        for b in blips:
            rid = b.get(qn("r:embed"))
            if not rid:
                continue
            try:
                blob = part.related_parts[rid].blob
            except Exception:
                continue
            img = QImage.fromData(blob)
            if img.isNull():
                continue
            w = img.width()
            ext = run_el.find(".//" + qn("wp:extent"))
            if ext is not None and ext.get("cx"):
                try:
                    w = int(ext.get("cx")) / 9525.0
                except Exception:
                    pass
            w = max(16, min(w, 640))
            self.img_n += 1
            name = "img%d" % self.img_n
            self.doc.addResource(QTextDocument.ResourceType.ImageResource, QUrl(name), img)
            fmt = QTextImageFormat()
            fmt.setName(name)
            fmt.setWidth(w)
            fmt.setHeight(w * img.height() / max(1, img.width()))
            cur.insertImage(fmt)

    def _fill(self, cur, p, heading, part):
        from docx.text.run import Run
        from docx.text.hyperlink import Hyperlink
        try:
            items = list(p.iter_inner_content())
        except Exception:
            items = list(p.runs)
        for it in items:
            if isinstance(it, Hyperlink):
                for r in it.runs:
                    f = _run_format(r, heading)
                    f.setForeground(QColor("#0563c1"))
                    f.setFontUnderline(True)
                    try:
                        f.setAnchor(True)
                        f.setAnchorHref(it.url or "")
                    except Exception:
                        pass
                    cur.insertText(r.text, f)
                continue
            r = it
            f = _run_format(r, heading)
            for child in r._r:
                tag = child.tag.split("}")[-1]
                if tag == "t":
                    cur.insertText(child.text or "", f)
                elif tag == "tab":
                    cur.insertText("\t", f)
                elif tag in ("br", "cr"):
                    from docx.oxml.ns import qn as _qn
                    if child.get(_qn("w:type")) == "page":
                        continue
                    cur.insertText("\u2028", f)
                elif tag == "drawing" or tag == "pict":
                    self._insert_image(cur, child, part)

    def _para_format(self, p):
        bf = QTextBlockFormat()
        try:
            a = p.alignment
            if a is not None:
                n = int(a)
                bf.setAlignment({0: Qt.AlignmentFlag.AlignLeft, 1: Qt.AlignmentFlag.AlignHCenter,
                                 2: Qt.AlignmentFlag.AlignRight, 3: Qt.AlignmentFlag.AlignJustify
                                 }.get(n, Qt.AlignmentFlag.AlignLeft))
        except Exception:
            pass
        try:
            pf = p.paragraph_format
            if pf.space_after is not None:
                bf.setBottomMargin(pf.space_after.pt)
            else:
                bf.setBottomMargin(6)
            if pf.space_before is not None:
                bf.setTopMargin(pf.space_before.pt)
            ls = pf.line_spacing
            if isinstance(ls, float) and 0.5 <= ls <= 5:
                bf.setLineHeight(ls * 100.0, QTextBlockFormat.LineHeightTypes.ProportionalHeight.value)
            if pf.left_indent is not None and pf.left_indent.cm > 0.3:
                bf.setIndent(int(round(pf.left_indent.cm / 1.27)))
        except Exception:
            bf.setBottomMargin(6)
        return bf

    def load(self, path):
        from docx import Document
        from docx.table import Table
        from docx.text.paragraph import Paragraph
        d = Document(path)
        doc = self.doc
        doc.clear()
        cur = QTextCursor(doc)
        fresh = True
        cur_list = None
        cur_kind = None
        for child in d.element.body.iterchildren():
            tag = child.tag.split("}")[-1]
            if tag == "p":
                p = Paragraph(child, d)
                has_break = bool(child.xpath('.//w:br[@w:type="page"]'))
                try:
                    pb_before = bool(p.paragraph_format.page_break_before)
                except Exception:
                    pb_before = False
                if (has_break and not p.text.strip()) or pb_before:
                    self._marker(cur, fresh)
                    fresh = False
                    cur_list = None
                    cur_kind = None
                    if has_break and not p.text.strip():
                        continue
                heading = self._heading_level(p)
                kind = None if heading else self._list_kind(p)
                bf = self._para_format(p)
                if heading:
                    bf.setHeadingLevel(heading)
                    bf.setTopMargin(10)
                if fresh and not (pb_before or has_break):
                    cur.setBlockFormat(bf)
                else:
                    cur.insertBlock(bf, QTextCharFormat())
                fresh = False
                if kind:
                    if cur_list is not None and cur_kind == kind:
                        cur_list.add(cur.block())
                    else:
                        lf = QTextListFormat()
                        lf.setStyle(QTextListFormat.Style.ListDisc if kind == BULLET
                                    else QTextListFormat.Style.ListDecimal)
                        lf.setIndent(1)
                        cur_list = cur.createList(lf)
                        cur_kind = kind
                else:
                    cur_list = None
                    cur_kind = None
                self._fill(cur, p, heading, d.part)
                if has_break and p.text.strip():
                    self._marker(cur, False)
                    cur_list = None
                    cur_kind = None
            elif tag == "tbl":
                cur_list = None
                cur_kind = None
                t = Table(child, d)
                self._table(cur, t, d, fresh)
                fresh = True
        return self._page_info(d)

    def _page_info(self, d):
        pg = default_page()
        try:
            sec = d.sections[0]
            pg["w"] = round(sec.page_width.mm, 1)
            pg["h"] = round(sec.page_height.mm, 1)
            pg["m"] = [round(sec.top_margin.cm, 2), round(sec.bottom_margin.cm, 2),
                       round(sec.left_margin.cm, 2), round(sec.right_margin.cm, 2)]
            ft = sec.footer
            pg["numbers"] = bool(ft._element.xpath('.//w:instrText[contains(., "PAGE")]'))
            pg["footer"] = " ".join(p.text.strip() for p in ft.paragraphs if p.text.strip())
            pg["header"] = " ".join(p.text for p in sec.header.paragraphs if p.text.strip())
        except Exception:
            pass
        return pg

    def _marker(self, cur, fresh):
        bf = QTextBlockFormat()
        bf.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        bf.setProperty(BREAK_PROP, True)
        if fresh:
            cur.setBlockFormat(bf)
        else:
            cur.insertBlock(bf, QTextCharFormat())
        cf = QTextCharFormat()
        cf.setForeground(QColor("#8a8f98"))
        cf.setFontPointSize(9)
        cur.insertText(BREAK_TEXT, cf)

    def _table(self, cur, t, d, fresh):
        from docx.text.paragraph import Paragraph
        rows = len(t.rows)
        cols = max((len(r._tr.tc_lst) for r in t.rows), default=0)
        if rows == 0 or cols == 0:
            return
        if not fresh:
            cur.insertBlock(QTextBlockFormat(), QTextCharFormat())
        tf = QTextTableFormat()
        tf.setBorder(1)
        tf.setBorderStyle(QTextFrameFormat.BorderStyle.BorderStyle_Solid)
        tf.setCellPadding(4)
        tf.setCellSpacing(0)
        tf.setWidth(QTextLength(QTextLength.Type.PercentageLength, 100))
        table = cur.insertTable(rows, cols, tf)
        for ri, row in enumerate(t.rows):
            tcs = row._tr.tc_lst
            for ci in range(min(cols, len(tcs))):
                from docx.table import _Cell
                cell = _Cell(tcs[ci], t)
                cc = table.cellAt(ri, ci).firstCursorPosition()
                first = True
                for para in cell.paragraphs:
                    if not first:
                        cc.insertBlock()
                    first = False
                    self._fill(cc, para, 0, d.part)
        cur.movePosition(QTextCursor.MoveOperation.End)


# --------------------------------------------------------------------------
#  QTextDocument  ->  DOCX
# --------------------------------------------------------------------------
def _align_to_docx(bf):
    from docx.enum.text import WD_ALIGN_PARAGRAPH as A
    a = bf.alignment()
    if a & Qt.AlignmentFlag.AlignHCenter:
        return A.CENTER
    if a & Qt.AlignmentFlag.AlignRight:
        return A.RIGHT
    if a & Qt.AlignmentFlag.AlignJustify:
        return A.JUSTIFY
    return None


def _apply_run(run, f, heading):
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_COLOR_INDEX
    if f.fontWeight() >= QFont.Weight.DemiBold.value:
        run.bold = True
    if f.fontItalic():
        run.italic = True
    if f.fontUnderline():
        run.underline = True
    if f.fontStrikeOut():
        run.font.strike = True
    va = f.verticalAlignment()
    if va == QTextCharFormat.VerticalAlignment.AlignSuperScript:
        run.font.superscript = True
    elif va == QTextCharFormat.VerticalAlignment.AlignSubScript:
        run.font.subscript = True
    if f.hasProperty(QTextFormat.Property.FontFamilies):
        fam = f.fontFamilies()
        if fam:
            run.font.name = fam[0] if isinstance(fam, list) else str(fam)
    sz = f.fontPointSize()
    if sz and not heading:
        run.font.size = Pt(sz)
    fg = f.foreground()
    if f.hasProperty(QTextFormat.Property.ForegroundBrush) and fg.style() != Qt.BrushStyle.NoBrush:
        c = fg.color()
        if c.rgb() & 0xFFFFFF != 0:
            run.font.color.rgb = RGBColor(c.red(), c.green(), c.blue())
    if f.hasProperty(QTextFormat.Property.BackgroundBrush) and f.background().style() != Qt.BrushStyle.NoBrush:
        run.font.highlight_color = WD_COLOR_INDEX.YELLOW


def _write_block(d, container, block, doc, first_para=None):
    """container: Document veya hücre. first_para: hücrenin boş ilk paragrafı."""
    bf = block.blockFormat()
    if bf.boolProperty(BREAK_PROP):
        if first_para is None:
            d.add_page_break()
        return
    heading = bf.headingLevel()
    lst = block.textList()
    style = None
    if heading:
        style = "Title" if False else "Heading %d" % min(heading, 4)
    elif lst is not None:
        st = lst.format().style()
        style = "List Number" if st in (QTextListFormat.Style.ListDecimal,
                                         QTextListFormat.Style.ListLowerAlpha,
                                         QTextListFormat.Style.ListUpperAlpha,
                                         QTextListFormat.Style.ListLowerRoman,
                                         QTextListFormat.Style.ListUpperRoman) else "List Bullet"
    p = first_para if first_para is not None else container.add_paragraph()
    if style:
        try:
            p.style = style
        except Exception:
            pass
    al = _align_to_docx(bf)
    if al is not None:
        p.alignment = al
    try:
        if (bf.lineHeightType() == QTextBlockFormat.LineHeightTypes.ProportionalHeight.value
                and bf.lineHeight() > 0 and abs(bf.lineHeight() - 100) > 1):
            p.paragraph_format.line_spacing = round(bf.lineHeight() / 100.0, 2)
        if lst is None and bf.indent() > 0:
            from docx.shared import Cm
            p.paragraph_format.left_indent = Cm(1.27 * bf.indent())
    except Exception:
        pass
    it = block.begin()
    while not it.atEnd():
        frag = it.fragment()
        it += 1
        if not frag.isValid():
            continue
        f = frag.charFormat()
        if f.isImageFormat():
            imf = f.toImageFormat()
            img = doc.resource(QTextDocument.ResourceType.ImageResource, QUrl(imf.name()))
            if isinstance(img, QImage) and not img.isNull():
                buf = QBuffer()
                buf.open(QIODevice.OpenModeFlag.WriteOnly)
                img.save(buf, "PNG")
                from docx.shared import Emu
                w = imf.width() or img.width()
                p.add_run().add_picture(io.BytesIO(bytes(buf.data())), width=Emu(int(w * 9525)))
            continue
        text = frag.text()
        parts = text.split("\u2028")
        for i, part in enumerate(parts):
            if i > 0:
                p.add_run().add_break()
            if part:
                if f.isAnchor() and f.anchorHref():
                    _add_hyperlink(p, part, f.anchorHref())
                    continue
                run = p.add_run(part.replace("\u00a0", " "))
                _apply_run(run, f, heading)


def save_docx(doc: QTextDocument, path, page=None):
    from docx import Document
    from docx.shared import Pt
    d = Document()
    st = d.styles["Normal"]
    st.font.name = DEFAULT_FONT
    st.font.size = Pt(DEFAULT_SIZE)
    _apply_section(d, page or default_page())
    # şablondaki boş ilk paragraf yok (python-docx boş başlar)
    done_tables = set()
    skip_until = -1
    block = doc.begin()
    while block.isValid():
        if block.position() <= skip_until:
            block = block.next()
            continue
        tbl = QTextCursor(block).currentTable()
        if tbl is not None:
            key = tbl.firstPosition()
            if key not in done_tables:
                done_tables.add(key)
                _write_table(d, tbl, doc)
            skip_until = tbl.lastPosition()
            block = block.next()
            continue
        nb = block.next()
        if (block.length() == 1 and block.textList() is None and nb.isValid()
                and QTextCursor(nb).currentTable() is not None):
            block = nb  # tablodan önceki boş satırı yazma
            continue
        _write_block(d, d, block, doc)
        block = nb
    if len(d.element.body) and d.element.body[-2 if len(d.element.body) > 1 else -1].tag.endswith("}tbl"):
        d.add_paragraph()
    d.save(path)


def _apply_section(d, pg):
    from docx.shared import Mm, Cm
    from docx.enum.section import WD_ORIENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH as A
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    sec = d.sections[0]
    sec.page_width = Mm(pg["w"])
    sec.page_height = Mm(pg["h"])
    sec.orientation = WD_ORIENT.LANDSCAPE if pg["w"] > pg["h"] else WD_ORIENT.PORTRAIT
    sec.top_margin, sec.bottom_margin = Cm(pg["m"][0]), Cm(pg["m"][1])
    sec.left_margin, sec.right_margin = Cm(pg["m"][2]), Cm(pg["m"][3])
    if pg.get("header"):
        sec.header.paragraphs[0].text = pg["header"]
    if pg.get("footer") or pg.get("numbers"):
        p = sec.footer.paragraphs[0]
        p.alignment = A.CENTER
        if pg.get("footer"):
            p.add_run(pg["footer"] + ("   " if pg.get("numbers") else ""))
        if pg.get("numbers"):
            r = p.add_run()
            for kind, txt in (("begin", None), (None, " PAGE "), ("end", None)):
                if kind:
                    e = OxmlElement("w:fldChar")
                    e.set(qn("w:fldCharType"), kind)
                else:
                    e = OxmlElement("w:instrText")
                    e.set(qn("xml:space"), "preserve")
                    e.text = txt
                r._r.append(e)


def _add_hyperlink(p, text, url):
    from docx.opc.constants import RELATIONSHIP_TYPE as RT
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    rid = p.part.relate_to(url, RT.HYPERLINK, is_external=True)
    h = OxmlElement("w:hyperlink")
    h.set(qn("r:id"), rid)
    r = OxmlElement("w:r")
    rpr = OxmlElement("w:rPr")
    c = OxmlElement("w:color")
    c.set(qn("w:val"), "0563C1")
    rpr.append(c)
    u = OxmlElement("w:u")
    u.set(qn("w:val"), "single")
    rpr.append(u)
    r.append(rpr)
    t = OxmlElement("w:t")
    t.set(qn("xml:space"), "preserve")
    t.text = text
    r.append(t)
    h.append(r)
    p._p.append(h)


def _write_table(d, tbl, doc):
    rows, cols = tbl.rows(), tbl.columns()
    t = d.add_table(rows=rows, cols=cols)
    try:
        t.style = "Table Grid"
    except Exception:
        pass
    for r in range(rows):
        for c in range(cols):
            cell = tbl.cellAt(r, c)
            dcell = t.cell(r, c)
            cur = cell.firstCursorPosition()
            blk = cur.block()
            end = cell.lastCursorPosition().block()
            first = True
            while blk.isValid():
                fp = dcell.paragraphs[0] if first else None
                _write_block(d, dcell, blk, doc, first_para=fp)
                first = False
                if blk == end or blk.position() >= end.position():
                    break
                blk = blk.next()


# --------------------------------------------------------------------------
#  Bul / Değiştir
# --------------------------------------------------------------------------
class FindDialog(QDialog):
    def __init__(self, editor, parent=None):
        super().__init__(parent)
        self.ed = editor
        self.setWindowTitle("Bul ve Değiştir")
        self.find = QLineEdit()
        self.repl = QLineEdit()
        self.case = QCheckBox("Büyük/küçük harfe duyarlı")
        self.info = QLabel("")
        form = QFormLayout()
        form.addRow("Bul:", self.find)
        form.addRow("Değiştir:", self.repl)
        b1 = QPushButton("Sonrakini bul")
        b2 = QPushButton("Önceki")
        b3 = QPushButton("Değiştir")
        b4 = QPushButton("Hepsini değiştir")
        row = QHBoxLayout()
        for b in (b2, b1, b3, b4):
            row.addWidget(b)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(self.case)
        lay.addLayout(row)
        lay.addWidget(self.info)
        b1.clicked.connect(lambda: self.go(False))
        b2.clicked.connect(lambda: self.go(True))
        b3.clicked.connect(self.replace_one)
        b4.clicked.connect(self.replace_all)
        self.find.returnPressed.connect(lambda: self.go(False))

    def _flags(self, back):
        f = QTextDocument.FindFlag(0)
        if self.case.isChecked():
            f |= QTextDocument.FindFlag.FindCaseSensitively
        if back:
            f |= QTextDocument.FindFlag.FindBackward
        return f

    def go(self, back):
        t = self.find.text()
        if not t:
            return False
        if self.ed.find(t, self._flags(back)):
            self.info.setText("")
            return True
        c = self.ed.textCursor()
        c.movePosition(QTextCursor.MoveOperation.End if back else QTextCursor.MoveOperation.Start)
        self.ed.setTextCursor(c)
        if self.ed.find(t, self._flags(back)):
            self.info.setText("Baştan/sondan devam edildi")
            return True
        self.info.setText("Bulunamadı")
        return False

    def replace_one(self):
        c = self.ed.textCursor()
        t = self.find.text()
        same = (c.selectedText() == t) if self.case.isChecked() else (c.selectedText().lower() == t.lower())
        if c.hasSelection() and same:
            c.insertText(self.repl.text())
        self.go(False)

    def replace_all(self):
        t = self.find.text()
        if not t:
            return
        n = 0
        c = self.ed.textCursor()
        c.movePosition(QTextCursor.MoveOperation.Start)
        self.ed.setTextCursor(c)
        self.ed.document().undo  # noqa
        c.beginEditBlock()
        while self.ed.find(t, self._flags(False)):
            self.ed.textCursor().insertText(self.repl.text())
            n += 1
        c.endEditBlock()
        self.info.setText("%d yerde değiştirildi" % n)


# --------------------------------------------------------------------------
#  Düzenleyici
# --------------------------------------------------------------------------
class PageDialog(QDialog):
    def __init__(self, page, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Sayfa yapısı")
        self.pg = dict(page)
        self.cb = QComboBox()
        self.cb.addItems(list(PAPER.keys()) + ["Özel"])
        w, h = page["w"], page["h"]
        port = (min(w, h), max(w, h))
        nm = "Özel"
        for n, (a, b) in PAPER.items():
            if abs(port[0] - a) < 1.5 and abs(port[1] - b) < 1.5:
                nm = n
        self.cb.setCurrentText(nm)
        self.ori = QComboBox()
        self.ori.addItems(["Dikey", "Yatay"])
        self.ori.setCurrentIndex(1 if w > h else 0)
        self.sw = QDoubleSpinBox(); self.sw.setRange(50, 1000); self.sw.setSuffix(" mm"); self.sw.setValue(port[0])
        self.sh = QDoubleSpinBox(); self.sh.setRange(50, 1500); self.sh.setSuffix(" mm"); self.sh.setValue(port[1])
        self.cb.currentTextChanged.connect(self._sync)
        self._sync(nm)
        self.m = []
        form = QFormLayout(self)
        form.addRow("Kağıt boyutu:", self.cb)
        form.addRow("Yön:", self.ori)
        form.addRow("Genişlik:", self.sw)
        form.addRow("Yükseklik:", self.sh)
        for lab, v in zip(("Üst boşluk:", "Alt boşluk:", "Sol boşluk:", "Sağ boşluk:"), page["m"]):
            sp = QDoubleSpinBox(); sp.setRange(0, 10); sp.setSingleStep(0.25); sp.setSuffix(" cm"); sp.setValue(v)
            self.m.append(sp)
            form.addRow(lab, sp)
        self.hd = QLineEdit(page.get("header", ""))
        self.ft = QLineEdit(page.get("footer", ""))
        self.num = QCheckBox("Sayfa numarası ekle (altta ortada)")
        self.num.setChecked(bool(page.get("numbers")))
        form.addRow("Üst bilgi yazısı:", self.hd)
        form.addRow("Alt bilgi yazısı:", self.ft)
        form.addRow("", self.num)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        form.addRow(bb)

    def _sync(self, name):
        custom = name == "Özel"
        self.sw.setEnabled(custom)
        self.sh.setEnabled(custom)
        if not custom:
            a, b = PAPER[name]
            self.sw.setValue(a)
            self.sh.setValue(b)

    def result_page(self):
        a, b = self.sw.value(), self.sh.value()
        w, h = (max(a, b), min(a, b)) if self.ori.currentIndex() == 1 else (min(a, b), max(a, b))
        return {"w": round(w, 1), "h": round(h, 1), "m": [x.value() for x in self.m],
                "header": self.hd.text().strip(), "footer": self.ft.text().strip(),
                "numbers": self.num.isChecked()}


class Page(QTextEdit):
    def __init__(self):
        super().__init__()
        self.setAcceptRichText(True)
        self.setStyleSheet("QTextEdit{background:#d5d9de;color:#111;border:none;"
                           "selection-background-color:#9ec5fe;selection-color:#000;}")
        self.setAcceptDrops(True)
        self.setMouseTracking(True)
        self.content_h = 0.0
        self.top_px = 0.0
        self.pages_enabled = True

    def canInsertFromMimeData(self, src):
        return src.hasUrls() or super().canInsertFromMimeData(src)

    def insertFromMimeData(self, src):
        if src.hasUrls():
            paths = [u.toLocalFile() for u in src.urls() if u.isLocalFile()]
            if paths:
                self.window().handle_files(paths)
                return
        if src.hasImage():
            img = src.imageData()
            if isinstance(img, QImage):
                self.window().insert_qimage(img)
                return
        super().insertFromMimeData(src)

    def mouseReleaseEvent(self, e):
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            href = self.anchorAt(e.pos())
            if href:
                QDesktopServices.openUrl(QUrl(href))
        super().mouseReleaseEvent(e)

    def paintEvent(self, e):
        super().paintEvent(e)
        if self.content_h <= 0:
            return
        p = QPainter(self.viewport())
        pen = QPen(QColor("#8a8f98"))
        pen.setStyle(Qt.PenStyle.DashLine)
        p.setPen(pen)
        scroll = self.verticalScrollBar().value()
        docw = self.viewport().width()
        y_end = self.document().size().height()
        k = 1
        while True:
            y_doc = self.top_px + k * self.content_h
            if y_doc - (self.content_h * 0.05) > y_end + self.content_h:
                break
            y = y_doc - scroll
            if 0 <= y <= self.viewport().height():
                p.drawLine(0, int(y), int(docw), int(y))
                p.drawText(int(docw - 90), int(y) - 3, "Sayfa %d" % (k + 1))
            k += 1
            if k > 2000:
                break
        p.end()


class AskWorker(QThread):
    done = pyqtSignal(str)

    def __init__(self, key, question, context):
        super().__init__()
        self.key, self.question, self.context = key, question, context

    def run(self):
        try:
            out = ask_gemini(self.key, self.question, self.context)
        except Exception as ex:
            out = "Hata / Error: %s" % ex
        self.done.emit(out)


class SettingsDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.setWindowTitle(T("Ayarlar"))
        self.resize(520, 240)
        self.lang = QComboBox()
        for code, name in LANG_NAMES:
            self.lang.addItem(name, code)
        self.lang.setCurrentIndex(max(0, self.lang.findData(cfg.get("dil", "tr"))))
        self.name = QLineEdit(cfg.get("asistan") or "Gemini")
        self.key = QLineEdit(cfg.get("gemini_key", ""))
        self.key.setEchoMode(QLineEdit.EchoMode.Password)
        hint = QLabel(T("Anahtarı al: aistudio.google.com/app/apikey  (anahtar bu bilgisayarda saklanır)"))
        hint.setWordWrap(True)
        form = QFormLayout()
        form.addRow(T("Dil:"), self.lang)
        form.addRow(T("Yapay zeka adı:"), self.name)
        form.addRow(T("Gemini API anahtarı:"), self.key)
        form.addRow("", hint)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(bb)


ACCENTS = [("Klasik", "#202124"), ("Modern", "#1a73e8"), ("Minimal", "#5f6368")]


def make_thumb(accent, kind):
    """Belgeye benzeyen küçük önizleme (Google Docs galerisi gibi)."""
    w, h = 130, 170
    pm = QPixmap(w, h)
    pm.fill(QColor("#f1f3f4"))
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(QPen(QColor("#dadce0"), 1))
    p.setBrush(QColor("#ffffff"))
    p.drawRect(10, 8, w - 20, h - 16)
    p.setPen(Qt.PenStyle.NoPen)
    if kind == "plus":
        p.setBrush(QColor(accent))
        p.drawRect(w // 2 - 3, h // 2 - 26, 6, 52)
        p.drawRect(w // 2 - 26, h // 2 - 3, 52, 6)
    else:
        p.setBrush(QColor(accent))
        p.drawRect(22, 22, w - 44, 12)
        p.setBrush(QColor("#c4c7c5"))
        for i in range(11):
            p.drawRect(22, 46 + i * 10, (w - 44) if i % 3 else (w - 80), 4)
    p.end()
    return pm


class StartDialog(QDialog):
    """Google Docs benzeri ana sayfa: arama, yeni belge kartları, son belgeler."""

    def __init__(self, recent, parent=None):
        super().__init__(parent)
        self.setWindowTitle(T("Belgem — Ana sayfa"))
        self.resize(920, 640)
        self.choice = None
        self.cards = []
        self.setStyleSheet(
            "QDialog{background:#f8f9fa;} QLabel{color:#202124;}"
            "QLineEdit{background:#ffffff;border:1px solid #dadce0;border-radius:20px;padding:9px 16px;font-size:14px;}"
            "QToolButton{background:transparent;border:0;color:#202124;font-size:12px;padding:4px;}"
            "QToolButton:hover{background:#e8f0fe;border-radius:8px;}"
            "QPushButton{background:#ffffff;border:1px solid #dadce0;border-radius:4px;padding:7px 14px;font-size:13px;}"
            "QPushButton:hover{background:#f1f3f4;}")

        self.search = QLineEdit()
        self.search.setPlaceholderText(T("Belgelerde ara..."))
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.refilter)

        head1 = QLabel(T("Yeni bir belge başlat"))
        head1.setStyleSheet("font-size:15px;font-weight:600;")
        row1 = QHBoxLayout()
        row1.setSpacing(14)
        row1.addWidget(self._card(T("Boş belge"), make_thumb("#4285f4", "plus"),
                                  ("blank", None), "boş belge blank yeni new"))
        L = CV_LANGS.get(LANG, CV_LANGS["tr"])
        base = build_cv_html(L)
        for name, accent in ACCENTS:
            page_html = (base.replace("<h1>", '<h1 style="color:%s">' % accent)
                             .replace("<h2>", '<h2 style="color:%s">' % accent))
            blob = (L["cv"] + " " + L["name"] + " cv resume " + name).lower()
            row1.addWidget(self._card(T(name), make_thumb(accent, "cv"), ("tpl", page_html), blob))
        row1.addStretch(1)

        head2 = QLabel(T("Son belgeler"))
        head2.setStyleSheet("font-size:15px;font-weight:600;")
        row2 = QHBoxLayout()
        row2.setSpacing(14)
        for p in recent:
            name = os.path.basename(p)
            row2.addWidget(self._card(name[:20], make_thumb("#1a73e8", "doc"), ("file", p),
                                      (name + " " + p).lower()))
        if not recent:
            empty = QLabel(T("Henüz belge yok"))
            row2.addWidget(empty)
        row2.addStretch(1)

        b_file = QPushButton(T("Dosya seç..."))
        b_file.clicked.connect(lambda: self.done_with(("browse", None)))
        bottom = QHBoxLayout()
        bottom.addStretch(1)
        bottom.addWidget(b_file)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 22, 28, 22)
        lay.setSpacing(14)
        lay.addWidget(self.search)
        lay.addSpacing(6)
        lay.addWidget(head1)
        lay.addLayout(row1)
        lay.addSpacing(10)
        lay.addWidget(head2)
        lay.addLayout(row2)
        lay.addStretch(1)
        lay.addLayout(bottom)
        self.search.setFocus()

    def _card(self, title, pm, value, blob):
        b = QToolButton()
        b.setIcon(QIcon(pm))
        b.setIconSize(QSize(130, 170))
        b.setText(title)
        b.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        b.setFixedWidth(150)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setProperty("blob", blob)
        b.clicked.connect(lambda _=False, v=value: self.done_with(v))
        self.cards.append(b)
        return b

    def refilter(self, *_):
        q = self.search.text().strip().lower()
        for b in self.cards:
            b.setVisible(not q or q in (b.property("blob") or ""))

    def done_with(self, choice):
        self.choice = choice
        self.accept()


class Main(QMainWindow):
    def __init__(self, path=None):
        super().__init__()
        self.path = None
        self.img_n = 0
        self.page = default_page()
        self.setAcceptDrops(True)
        self.setWindowTitle(APP)
        self.resize(980, 660)
        self.bw = load_bw()
        self.ed = Page()
        self.setCentralWidget(self.ed)
        self.ed.document().setDefaultFont(QFont(DEFAULT_FONT, DEFAULT_SIZE))
        self.ed.document().setDocumentMargin(0)
        self.ed.setFont(QFont(DEFAULT_FONT, DEFAULT_SIZE))
        self.build_actions()
        self.build_assistant()
        self.apply_theme()
        self.lbl = QLabel("")
        self.statusBar().addPermanentWidget(self.lbl)
        self.ed.textChanged.connect(self.update_status)
        self.ed.document().documentLayout().documentSizeChanged.connect(lambda _: self.update_status())
        self.ed.cursorPositionChanged.connect(self.sync_format)
        self.ed.cursorPositionChanged.connect(self.update_status)
        self.ed.verticalScrollBar().valueChanged.connect(lambda _: self.ed.viewport().update())
        self.ed.document().modificationChanged.connect(self.update_title)
        self.find_dlg = None
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.autosave)
        self.timer.start(30000)
        self.apply_page()
        self.update_status()
        self.update_title()
        if path:
            self.open_path(path)
        else:
            self.check_recovery()
            if self.path is None and not self.ed.toPlainText().strip():
                self.show_start()

    # ---------- yapay zeka yardımcısı ----------
    def assistant_name(self):
        return load_cfg().get("asistan") or "Gemini"

    def build_assistant(self):
        self.dock = QDockWidget(self.assistant_name(), self)
        box = QWidget()
        self.ai_out = QTextBrowser()
        self.ai_in = QLineEdit()
        self.ai_in.setPlaceholderText(T("Bir soru yaz... (Enter)"))
        self.ai_ctx = QCheckBox(T("Açık belgeyi de gönder"))
        self.ai_ctx.setChecked(True)
        self.ai_btn = QPushButton(T("Gönder"))
        row = QHBoxLayout()
        row.addWidget(self.ai_in, 1)
        row.addWidget(self.ai_btn)
        lay = QVBoxLayout(box)
        lay.addWidget(self.ai_out, 1)
        lay.addWidget(self.ai_ctx)
        lay.addLayout(row)
        self.dock.setWidget(box)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dock)
        self.dock.hide()
        self.a_ai = QAction(self.assistant_name(), self)
        self.a_ai.setCheckable(True)
        self.a_ai.setToolTip(T("Yapay zeka yardımcısını aç/kapat"))
        self.a_ai.toggled.connect(self.dock.setVisible)
        self.dock.visibilityChanged.connect(self.a_ai.setChecked)
        self.t1.addSeparator()
        self.t1.addAction(self.a_ai)
        self.gm.addAction(self.a_ai)
        self.ai_btn.clicked.connect(self.ai_send)
        self.ai_in.returnPressed.connect(self.ai_send)

    def ai_send(self):
        q = self.ai_in.text().strip()
        if not q or not self.ai_btn.isEnabled():
            return
        key = (load_cfg().get("gemini_key") or "").strip()
        if not key:
            self.ai_out.append(T("Önce Dosya → Ayarlar bölümünden Gemini API anahtarını gir."))
            return
        ctx = self.ed.toPlainText()[:12000] if self.ai_ctx.isChecked() else ""
        self.ai_out.append("<b>%s:</b> %s" % (T("Sen"), html.escape(q)))
        self.ai_in.clear()
        self.ai_btn.setEnabled(False)
        self.statusBar().showMessage(T("Yanıt bekleniyor..."))
        self.worker = AskWorker(key, q, ctx)
        self.worker.done.connect(self.ai_done)
        self.worker.start()

    def ai_done(self, text):
        self.ai_btn.setEnabled(True)
        self.statusBar().clearMessage()
        self.ai_out.append("<b>%s:</b> %s" % (html.escape(self.assistant_name()),
                                             html.escape(text).replace("\n", "<br>")))

    def open_settings(self):
        cfg = load_cfg()
        dlg = SettingsDialog(cfg, self)
        if not dlg.exec():
            return
        old_lang = cfg.get("dil", "tr")
        cfg["dil"] = dlg.lang.currentData()
        cfg["asistan"] = dlg.name.text().strip() or "Gemini"
        cfg["gemini_key"] = dlg.key.text().strip()
        save_cfg(cfg)
        self.dock.setWindowTitle(cfg["asistan"])
        self.a_ai.setText(cfg["asistan"])
        if cfg["dil"] != old_lang:
            QMessageBox.information(self, APP, T("Dil değişikliği uygulamayı yeniden açınca tam görünür."))

    # ---------- ana sayfa ----------
    def show_start(self):
        if not self.maybe_save():
            return
        dlg = StartDialog(self.recent(), self)
        if not dlg.exec() or not dlg.choice:
            return
        kind, val = dlg.choice
        if kind == "tpl":
            self.use_template(val)
        elif kind == "file":
            self.open_path(val)
        elif kind == "browse":
            self.open_dialog()
        else:
            self._blank()

    def use_template(self, html_src):
        doc = self.ed.document()
        doc.clear()
        doc.setDefaultFont(QFont(DEFAULT_FONT, DEFAULT_SIZE))
        self.ed.setHtml(html_src)
        self.page = default_page()
        self.path = None
        self.apply_page()
        doc.setModified(True)
        self.clear_recovery()
        self.update_title()

    def _blank(self):
        doc = self.ed.document()
        doc.clear()
        doc.setDefaultFont(QFont(DEFAULT_FONT, DEFAULT_SIZE))
        self.page = default_page()
        self.apply_page()
        self.path = None
        doc.setModified(False)
        self.clear_recovery()
        self.update_title()

    def recent(self):
        return [p for p in load_cfg().get("son", []) if isinstance(p, str) and os.path.exists(p)]

    def add_recent(self, p):
        p = os.path.abspath(p)
        cfg = load_cfg()
        rest = [x for x in cfg.get("son", []) if x != p]
        cfg["son"] = ([p] + rest)[:10]
        save_cfg(cfg)

    # ---------- görünüm ----------
    def apply_theme(self):
        c = theme_css(self.bw)
        self.setStyleSheet(c["app"])
        self.ed.setStyleSheet(c["ed_css"])

    def toggle_bw(self, on):
        self.bw = bool(on)
        save_bw(self.bw)
        self.apply_theme()

    # ---------- kurulum ----------
    def act(self, text, slot, key=None, check=False, tip=None):
        a = QAction(T(text), self)
        if key:
            a.setShortcut(QKeySequence(key))
        a.setCheckable(check)
        a.triggered.connect(slot)
        if tip:
            a.setToolTip(T(tip))
        return a

    def build_actions(self):
        t1 = self.t1 = QToolBar(T("Dosya"))
        t1.setMovable(False)
        t1.setIconSize(QSize(16, 16))
        self.addToolBar(t1)
        self.a_new = self.act("Yeni", self.new_doc, QKeySequence.StandardKey.New)
        self.a_open = self.act("Aç", self.open_dialog, QKeySequence.StandardKey.Open)
        self.a_save = self.act("Kaydet", self.save, QKeySequence.StandardKey.Save)
        self.a_saveas = self.act("Farklı kaydet", self.save_as, "Ctrl+Shift+S")
        self.a_pdf = self.act("PDF olarak kaydet", self.export_pdf)
        self.a_undo = self.act("Geri al", self.ed.undo, QKeySequence.StandardKey.Undo)
        self.a_redo = self.act("Yinele", self.ed.redo, QKeySequence.StandardKey.Redo)
        self.a_find = self.act("Bul / Değiştir", self.open_find, "Ctrl+F")
        for a in (self.a_new, self.a_open, self.a_save, self.a_saveas, self.a_pdf):
            t1.addAction(a)
        t1.addSeparator()
        for a in (self.a_undo, self.a_redo, self.a_find):
            t1.addAction(a)
        self.a_print = self.act("Yazdır", self.print_doc, "Ctrl+P")
        t1.addAction(self.a_print)
        self.a_pagesetup = self.act("Sayfa yapısı", self.page_setup)
        t1.addAction(self.a_pagesetup)
        t1.addSeparator()
        self.a_bw = self.act("Siyah beyaz", self.toggle_bw, None, True, "Siyah beyaz görünüm aç/kapat")
        self.a_bw.setChecked(self.bw)
        t1.addAction(self.a_bw)

        self.addToolBarBreak()
        t2 = QToolBar(T("Biçim"))
        t2.setMovable(False)
        self.addToolBar(t2)
        self.cb_style = QComboBox()
        self.cb_style.addItems(["Normal", "Başlık 1", "Başlık 2", "Başlık 3"])
        self.cb_style.activated.connect(self.set_heading)
        t2.addWidget(self.cb_style)
        self.cb_font = QFontComboBox()
        self.cb_font.setCurrentFont(QFont(DEFAULT_FONT))
        self.cb_font.textActivated.connect(self.set_font)
        t2.addWidget(self.cb_font)
        self.sp_size = QSpinBox()
        self.sp_size.setRange(6, 96)
        self.sp_size.setValue(DEFAULT_SIZE)
        self.sp_size.valueChanged.connect(self.set_size)
        t2.addWidget(self.sp_size)
        t2.addSeparator()
        self.a_b = self.act("K", lambda: self.toggle("b"), "Ctrl+B", True, "Kalın (Ctrl+B)")
        self.a_i = self.act("E", lambda: self.toggle("i"), "Ctrl+I", True, "Eğik (Ctrl+I)")
        self.a_u = self.act("A", lambda: self.toggle("u"), "Ctrl+U", True, "Altı çizili (Ctrl+U)")
        self.a_s = self.act("Ü", lambda: self.toggle("s"), None, True, "Üstü çizili")
        f = self.a_b.font(); f.setBold(True); self.a_b.setFont(f)
        f = self.a_i.font(); f.setItalic(True); self.a_i.setFont(f)
        f = self.a_u.font(); f.setUnderline(True); self.a_u.setFont(f)
        f = self.a_s.font(); f.setStrikeOut(True); self.a_s.setFont(f)
        for a in (self.a_b, self.a_i, self.a_u, self.a_s):
            t2.addAction(a)
        self.a_col = self.act("Renk", self.pick_color, None, False, "Yazı rengi")
        self.a_hl = self.act("Vurgu", self.highlight, None, False, "Sarı vurgu aç/kapat")
        t2.addAction(self.a_col)
        t2.addAction(self.a_hl)
        t2.addSeparator()
        self.al = {}
        for key, txt, fl in (("l", "Sol", Qt.AlignmentFlag.AlignLeft),
                             ("c", "Orta", Qt.AlignmentFlag.AlignHCenter),
                             ("r", "Sağ", Qt.AlignmentFlag.AlignRight),
                             ("j", "İki yana", Qt.AlignmentFlag.AlignJustify)):
            a = self.act(txt, lambda _=False, fl=fl: self.ed.setAlignment(fl), None, True)
            self.al[key] = (a, fl)
            t2.addAction(a)
        t2.addSeparator()
        self.a_bul = self.act("• Liste", lambda: self.make_list(BULLET), None, True)
        self.a_num = self.act("1. Liste", lambda: self.make_list(NUMBER), None, True)
        t2.addAction(self.a_bul)
        t2.addAction(self.a_num)
        t2.addSeparator()
        t2.addAction(self.act("Tablo", self.insert_table))
        t2.addAction(self.act("Resim", self.insert_image))

        self.addToolBarBreak()
        t3 = QToolBar(T("Ek"))
        t3.setMovable(False)
        self.addToolBar(t3)
        self.cb_ls = QComboBox()
        for v in ("1.0", "1.15", "1.5", "2.0", "3.0"):
            self.cb_ls.addItem("Satır aralığı " + v, float(v))
        self.cb_ls.setCurrentIndex(0)
        self.cb_ls.activated.connect(self.set_linespacing)
        t3.addWidget(self.cb_ls)
        t3.addAction(self.act("◀ Girinti", lambda: self.indent(-1), None, False, "Girintiyi azalt"))
        t3.addAction(self.act("Girinti ▶", lambda: self.indent(1), None, False, "Girintiyi artır"))
        t3.addSeparator()
        self.a_sup = self.act("X²", lambda: self.script("sup"), None, True, "Üst simge")
        self.a_sub = self.act("X₂", lambda: self.script("sub"), None, True, "Alt simge")
        t3.addAction(self.a_sup)
        t3.addAction(self.a_sub)
        t3.addAction(self.act("Biçimi temizle", self.clear_format))
        t3.addSeparator()
        t3.addAction(self.act("Bağlantı", self.insert_link, "Ctrl+K", False, "Bağlantı ekle (Ctrl+K)"))
        t3.addAction(self.act("Sayfa sonu", self.insert_page_break, "Ctrl+Return", False, "Sayfa sonu ekle (Ctrl+Enter)"))
        t3.addAction(self.act("Tümünü seç", self.ed.selectAll, QKeySequence.StandardKey.SelectAll))
        self.lbl_page = QLabel("")

        m = self.menuBar()
        fm = m.addMenu(T("Dosya"))
        for a in (self.a_new, self.a_open, self.a_save, self.a_saveas, self.a_pdf):
            fm.addAction(a)
        fm.addAction(self.act("Ana sayfa (CV kalıpları)", self.show_start))
        fm.addAction(self.act("Ayarlar", self.open_settings))
        fm.addSeparator()
        fm.addAction(self.act("Çıkış", self.close, "Ctrl+Q"))
        em = m.addMenu(T("Düzen"))
        for a in (self.a_undo, self.a_redo, self.a_find):
            em.addAction(a)
        pm = m.addMenu(T("Sayfa"))
        pm.addAction(self.a_pagesetup)
        pm.addAction(self.act("Sayfa sonu ekle", self.insert_page_break))
        pm.addAction(self.a_print)
        self.gm = m.addMenu(T("Görünüm"))
        self.gm.addAction(self.a_bw)
        hm = m.addMenu(T("Yardım"))
        hm.addAction(self.act("Belgem hakkında", self.about))

    # ---------- biçimlendirme ----------
    def merge(self, fmt):
        c = self.ed.textCursor()
        c.mergeCharFormat(fmt)
        self.ed.mergeCurrentCharFormat(fmt)

    def toggle(self, k):
        f = QTextCharFormat()
        if k == "b":
            on = self.a_b.isChecked()
            f.setFontWeight(QFont.Weight.Bold if on else QFont.Weight.Normal)
        elif k == "i":
            f.setFontItalic(self.a_i.isChecked())
        elif k == "u":
            f.setFontUnderline(self.a_u.isChecked())
        elif k == "s":
            f.setFontStrikeOut(self.a_s.isChecked())
        self.merge(f)

    def set_font(self, name):
        f = QTextCharFormat()
        f.setFontFamilies([name])
        self.merge(f)

    def set_size(self, v):
        f = QTextCharFormat()
        f.setFontPointSize(float(v))
        self.merge(f)

    def pick_color(self):
        c = QColorDialog.getColor(self.ed.textColor(), self, "Yazı rengi")
        if c.isValid():
            f = QTextCharFormat()
            f.setForeground(c)
            self.merge(f)

    def highlight(self):
        cur = self.ed.currentCharFormat()
        f = QTextCharFormat()
        if cur.background().style() != Qt.BrushStyle.NoBrush and cur.background().color() == QColor("#ffff00"):
            f.setBackground(Qt.GlobalColor.transparent)
            f.clearBackground()
            c = self.ed.textCursor()
            if c.hasSelection():
                nf = QTextCharFormat()
                nf.setBackground(Qt.GlobalColor.white)
                self.merge(nf)
            return
        f.setBackground(QColor("#ffff00"))
        self.merge(f)

    def set_heading(self, idx):
        c = self.ed.textCursor()
        c.beginEditBlock()
        bf = c.blockFormat()
        bf.setHeadingLevel(idx)
        c.setBlockFormat(bf)
        cf = QTextCharFormat()
        cf.setFontWeight(QFont.Weight.Bold if idx else QFont.Weight.Normal)
        cf.setFontPointSize(HEAD_SIZES.get(idx, DEFAULT_SIZE) if idx else DEFAULT_SIZE)
        c.movePosition(QTextCursor.MoveOperation.StartOfBlock)
        c.movePosition(QTextCursor.MoveOperation.EndOfBlock, QTextCursor.MoveMode.KeepAnchor)
        c.mergeCharFormat(cf)
        c.endEditBlock()
        self.ed.mergeCurrentCharFormat(cf)
        self.sync_format()

    def make_list(self, kind):
        c = self.ed.textCursor()
        lst = c.currentList()
        want = QTextListFormat.Style.ListDisc if kind == BULLET else QTextListFormat.Style.ListDecimal
        c.beginEditBlock()
        if lst is not None and lst.format().style() == want:
            bf = c.blockFormat()
            bf.setIndent(0)
            c.setBlockFormat(bf)
            lst.remove(c.block())
        else:
            lf = QTextListFormat()
            lf.setStyle(want)
            lf.setIndent(1)
            c.createList(lf)
        c.endEditBlock()
        self.sync_format()

    def sync_format(self):
        f = self.ed.currentCharFormat()
        for a, v in ((self.a_b, f.fontWeight() >= QFont.Weight.DemiBold.value),
                     (self.a_i, f.fontItalic()), (self.a_u, f.fontUnderline()),
                     (self.a_s, f.fontStrikeOut())):
            a.blockSignals(True)
            a.setChecked(v)
            a.blockSignals(False)
        al = self.ed.alignment()
        for k, (a, fl) in self.al.items():
            a.blockSignals(True)
            a.setChecked(bool(al & fl) if k != "l" else bool(al & Qt.AlignmentFlag.AlignLeft))
            a.blockSignals(False)
        lst = self.ed.textCursor().currentList()
        st = lst.format().style() if lst is not None else None
        self.a_bul.blockSignals(True)
        self.a_num.blockSignals(True)
        self.a_bul.setChecked(st == QTextListFormat.Style.ListDisc)
        self.a_num.setChecked(st == QTextListFormat.Style.ListDecimal)
        self.a_bul.blockSignals(False)
        self.a_num.blockSignals(False)
        self.cb_style.blockSignals(True)
        self.cb_style.setCurrentIndex(min(3, self.ed.textCursor().blockFormat().headingLevel()))
        self.cb_style.blockSignals(False)
        sz = f.fontPointSize()
        self.sp_size.blockSignals(True)
        self.sp_size.setValue(int(round(sz)) if sz else DEFAULT_SIZE)
        self.sp_size.blockSignals(False)
        fam = f.fontFamilies()
        self.cb_font.blockSignals(True)
        self.cb_font.setCurrentFont(QFont(fam[0] if fam else DEFAULT_FONT))
        self.cb_font.blockSignals(False)

    def insert_table(self):
        r, ok = QInputDialog.getInt(self, "Tablo", "Satır sayısı:", 3, 1, 50)
        if not ok:
            return
        c, ok = QInputDialog.getInt(self, "Tablo", "Sütun sayısı:", 3, 1, 12)
        if not ok:
            return
        tf = QTextTableFormat()
        tf.setBorder(1)
        tf.setBorderStyle(QTextFrameFormat.BorderStyle.BorderStyle_Solid)
        tf.setCellPadding(4)
        tf.setCellSpacing(0)
        tf.setWidth(QTextLength(QTextLength.Type.PercentageLength, 100))
        self.ed.textCursor().insertTable(r, c, tf)

    def insert_image(self):
        p, _ = QFileDialog.getOpenFileName(self, "Resim seç", "",
                                           "Resimler (*.png *.jpg *.jpeg *.bmp *.gif)")
        if p:
            img = QImage(p)
            if img.isNull():
                QMessageBox.warning(self, APP, "Resim açılamadı.")
                return
            self.insert_qimage(img)

    def insert_qimage(self, img):
        self.img_n += 1
        name = "yeni%d" % self.img_n
        self.ed.document().addResource(QTextDocument.ResourceType.ImageResource, QUrl(name), img)
        fmt = QTextImageFormat()
        fmt.setName(name)
        w = min(img.width(), 600)
        fmt.setWidth(w)
        fmt.setHeight(w * img.height() / max(1, img.width()))
        self.ed.textCursor().insertImage(fmt)

    # ---------- sayfa ----------
    def apply_page(self):
        pg = self.page
        doc = self.ed.document()
        doc.setDocumentMargin(0)
        rf = doc.rootFrame()
        ff = rf.frameFormat()
        t, b, l, r = [mm_px(x * 10) for x in pg["m"]]
        ff.setTopMargin(t)
        ff.setBottomMargin(b)
        ff.setLeftMargin(l)
        ff.setRightMargin(r)
        ff.setBackground(QColor("#ffffff"))
        ff.setBorder(0)
        rf.setFrameFormat(ff)
        self.ed.top_px = t
        self.ed.content_h = max(50.0, mm_px(pg["h"]) - t - b)
        self.layout_page()
        self.update_status()

    def layout_page(self):
        pagew = mm_px(self.page["w"])
        avail = self.ed.width() - self.ed.verticalScrollBar().sizeHint().width()
        m = int(max(8, (avail - pagew) // 2))
        self.ed.setViewportMargins(m, 14, m, 14)
        self.ed.viewport().update()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.layout_page()

    def page_setup(self):
        dlg = PageDialog(self.page, self)
        if dlg.exec():
            self.page = dlg.result_page()
            self.ed.document().setModified(True)
            self.apply_page()
            self.update_title()

    def insert_page_break(self):
        c = self.ed.textCursor()
        c.beginEditBlock()
        c.movePosition(QTextCursor.MoveOperation.EndOfBlock)
        bf = QTextBlockFormat()
        bf.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        bf.setProperty(BREAK_PROP, True)
        cf = QTextCharFormat()
        cf.setForeground(QColor("#8a8f98"))
        cf.setFontPointSize(9)
        c.insertBlock(bf, cf)
        c.insertText(BREAK_TEXT, cf)
        c.insertBlock(QTextBlockFormat(), QTextCharFormat())
        c.endEditBlock()
        self.ed.setTextCursor(c)

    # ---------- ek özellikler ----------
    def set_linespacing(self, idx):
        v = self.cb_ls.itemData(idx)
        c = self.ed.textCursor()
        c.beginEditBlock()
        sel = QTextCursor(c)
        start, end = sorted((c.anchor(), c.position()))
        sel.setPosition(start)
        blk = sel.block()
        while blk.isValid() and blk.position() <= end:
            cc = QTextCursor(blk)
            bf = cc.blockFormat()
            bf.setLineHeight(v * 100.0, QTextBlockFormat.LineHeightTypes.ProportionalHeight.value)
            cc.setBlockFormat(bf)
            blk = blk.next()
        c.endEditBlock()

    def indent(self, d):
        c = self.ed.textCursor()
        c.beginEditBlock()
        start, end = sorted((c.anchor(), c.position()))
        sel = QTextCursor(c)
        sel.setPosition(start)
        blk = sel.block()
        while blk.isValid() and blk.position() <= end:
            cc = QTextCursor(blk)
            bf = cc.blockFormat()
            bf.setIndent(max(0, bf.indent() + d))
            cc.setBlockFormat(bf)
            blk = blk.next()
        c.endEditBlock()

    def script(self, k):
        f = QTextCharFormat()
        VA = QTextCharFormat.VerticalAlignment
        on = (self.a_sup if k == "sup" else self.a_sub).isChecked()
        if on:
            f.setVerticalAlignment(VA.AlignSuperScript if k == "sup" else VA.AlignSubScript)
        else:
            f.setVerticalAlignment(VA.AlignNormal)
        self.merge(f)

    def clear_format(self):
        c = self.ed.textCursor()
        if c.hasSelection():
            c.setCharFormat(QTextCharFormat())
        else:
            self.ed.setCurrentCharFormat(QTextCharFormat())

    def insert_link(self):
        url, ok = QInputDialog.getText(self, "Bağlantı", "Adres (örn. https://google.com):")
        url = url.strip()
        if not ok or not url:
            return
        if "://" not in url and not url.startswith("mailto:"):
            url = "https://" + url
        f = QTextCharFormat()
        f.setAnchor(True)
        f.setAnchorHref(url)
        f.setForeground(QColor("#0563c1"))
        f.setFontUnderline(True)
        c = self.ed.textCursor()
        if c.hasSelection():
            c.mergeCharFormat(f)
        else:
            c.insertText(url, f)
            c.insertText(" ", QTextCharFormat())
            self.ed.setTextCursor(c)

    def print_doc(self):
        pr = self._printer()
        dlg = QPrintDialog(pr, self)
        if dlg.exec():
            self._print_to(pr)

    def _printer(self):
        pr = QPrinter(QPrinter.PrinterMode.HighResolution)
        pg = self.page
        ps = QPageSize(QSizeF(min(pg["w"], pg["h"]), max(pg["w"], pg["h"])),
                       QPageSize.Unit.Millimeter)
        ori = QPageLayout.Orientation.Landscape if pg["w"] > pg["h"] else QPageLayout.Orientation.Portrait
        m = pg["m"]
        pr.setPageLayout(QPageLayout(ps, ori, QMarginsF(m[2] * 10, m[0] * 10, m[3] * 10, m[1] * 10),
                                     QPageLayout.Unit.Millimeter))
        return pr

    def _print_to(self, pr):
        d = self.ed.document().clone()
        rf = d.rootFrame()
        ff = rf.frameFormat()
        ff.setTopMargin(0); ff.setBottomMargin(0); ff.setLeftMargin(0); ff.setRightMargin(0)
        ff.setBackground(QColor("#ffffff"))
        rf.setFrameFormat(ff)
        d.print(pr)

    # ---------- sürükle bırak ----------
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        paths = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.handle_files(paths)
            e.acceptProposedAction()

    def handle_files(self, paths):
        imgs = [p for p in paths if p.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".gif"))]
        docs = [p for p in paths if p.lower().endswith((".docx", ".txt"))]
        if docs:
            if self.maybe_save():
                self.open_path(docs[0])
            return
        for p in imgs:
            img = QImage(p)
            if not img.isNull():
                self.insert_qimage(img)
        if not imgs:
            QMessageBox.information(self, APP, "Bu dosya türü açılamıyor. .docx, .txt veya resim bırakabilirsin.")

    # ---------- dosya ----------
    def update_title(self, *_):
        name = os.path.basename(self.path) if self.path else "Adsız"
        star = "*" if self.ed.document().isModified() else ""
        self.setWindowTitle("%s%s - %s" % (star, name, APP))

    def update_status(self):
        txt = self.ed.toPlainText()
        words = len(txt.split())
        ch = self.ed.content_h or 1.0
        top = self.ed.top_px
        docH = self.ed.document().size().height()
        bot = mm_px(self.page["m"][1] * 10)
        total = max(1, int(-(-(docH - top - bot) // ch)))
        y = self.ed.cursorRect().top() + self.ed.verticalScrollBar().value()
        cur = max(1, min(total, int((y - top) // ch) + 1))
        pg = self.page
        self.lbl.setText("Sayfa %d / %d   ·   %s (%g × %g mm)   ·   %d kelime   %d karakter  " % (
            cur, total, paper_name(pg["w"], pg["h"]), pg["w"], pg["h"], words, len(txt)))

    def maybe_save(self):
        if not self.ed.document().isModified():
            return True
        b = QMessageBox(self)
        b.setWindowTitle(APP)
        b.setText("Değişiklikler kaydedilsin mi?")
        ks = b.addButton("Kaydet", QMessageBox.ButtonRole.AcceptRole)
        kn = b.addButton("Kaydetme", QMessageBox.ButtonRole.DestructiveRole)
        b.addButton("İptal", QMessageBox.ButtonRole.RejectRole)
        b.exec()
        if b.clickedButton() == ks:
            return self.save()
        return b.clickedButton() == kn

    def new_doc(self):
        if not self.maybe_save():
            return
        self.ed.document().clear()
        self.ed.document().setDefaultFont(QFont(DEFAULT_FONT, DEFAULT_SIZE))
        self.page = default_page()
        self.apply_page()
        self.path = None
        self.ed.document().setModified(False)
        self.clear_recovery()
        self.update_title()

    def open_dialog(self):
        if not self.maybe_save():
            return
        p, _ = QFileDialog.getOpenFileName(self, "Belge aç", "",
                                           "Belgeler (*.docx *.txt);;Word (*.docx);;Metin (*.txt)")
        if p:
            self.open_path(p)

    def open_path(self, p):
        try:
            if p.lower().endswith(".docx"):
                self.page = Loader(self.ed.document()).load(p)
            else:
                self.page = default_page()
                raw = open(p, "rb").read()
                try:
                    s = raw.decode("utf-8-sig")
                except UnicodeDecodeError:
                    s = raw.decode("cp1254", "replace")
                self.ed.document().clear()
                self.ed.setPlainText(s)
            self.ed.document().setDefaultFont(QFont(DEFAULT_FONT, DEFAULT_SIZE))
            self.apply_page()
            self.path = p if p.lower().endswith(".docx") else None
            self.ed.document().setModified(False)
            self.ed.moveCursor(QTextCursor.MoveOperation.Start)
            self.clear_recovery()
            self.update_title()
            if self.path:
                self.add_recent(self.path)
        except Exception as ex:
            traceback.print_exc()
            QMessageBox.warning(self, APP, "Dosya açılamadı.\n\n%s: %s\n\n"
                                "Not: eski .doc dosyalarını önce Word ile .docx olarak kaydet." %
                                (type(ex).__name__, ex))

    def save(self):
        if not self.path:
            return self.save_as()
        return self._write(self.path)

    def save_as(self):
        start = self.path or "Belge.docx"
        p, _ = QFileDialog.getSaveFileName(self, "Farklı kaydet", start, "Word (*.docx)")
        if not p:
            return False
        if not p.lower().endswith(".docx"):
            p += ".docx"
        if self._write(p):
            self.path = p
            self.update_title()
            return True
        return False

    def _write(self, p):
        try:
            save_docx(self.ed.document(), p, self.page)
        except PermissionError:
            QMessageBox.warning(self, APP, "Kaydedilemedi. Dosya başka bir programda (Word gibi) "
                                "açık olabilir; onu kapatıp tekrar dene.")
            return False
        except Exception as ex:
            traceback.print_exc()
            QMessageBox.warning(self, APP, "Kaydedilemedi: %s: %s" % (type(ex).__name__, ex))
            return False
        self.ed.document().setModified(False)
        self.clear_recovery()
        self.statusBar().showMessage("Kaydedildi", 3000)
        self.add_recent(p)
        self.update_title()
        return True

    def export_pdf(self):
        p, _ = QFileDialog.getSaveFileName(self, "PDF kaydet", "Belge.pdf", "PDF (*.pdf)")
        if not p:
            return
        if not p.lower().endswith(".pdf"):
            p += ".pdf"
        pr = self._printer()
        pr.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
        pr.setOutputFileName(p)
        self._print_to(pr)
        self.statusBar().showMessage("PDF kaydedildi", 3000)

    # ---------- kurtarma ----------
    def rec_paths(self):
        d = data_dir()
        return os.path.join(d, "kurtarma.docx"), os.path.join(d, "kurtarma.json")

    def autosave(self):
        if not self.ed.document().isModified():
            return
        try:
            a, b = self.rec_paths()
            save_docx(self.ed.document(), a, self.page)
            json.dump({"path": self.path}, open(b, "w", encoding="utf-8"))
        except Exception:
            pass

    def clear_recovery(self):
        for p in self.rec_paths():
            try:
                os.remove(p)
            except OSError:
                pass

    def check_recovery(self):
        a, b = self.rec_paths()
        if os.path.exists(a):
            r = QMessageBox.question(self, APP, "Geçen sefer kaydedilmemiş bir çalışma kalmış.\n"
                                     "Geri getirilsin mi?")
            if r == QMessageBox.StandardButton.Yes:
                try:
                    orig = json.load(open(b, encoding="utf-8")).get("path")
                except Exception:
                    orig = None
                self.open_path(a)
                self.path = orig
                self.ed.document().setModified(True)
                self.update_title()
            else:
                self.clear_recovery()

    def open_find(self):
        if self.find_dlg is None:
            self.find_dlg = FindDialog(self.ed, self)
        c = self.ed.textCursor()
        if c.hasSelection():
            self.find_dlg.find.setText(c.selectedText())
        self.find_dlg.show()
        self.find_dlg.raise_()
        self.find_dlg.find.setFocus()

    def about(self):
        QMessageBox.information(self, APP, "Belgem — ücretsiz DOCX okuyucu ve düzenleyici.\n\n"
                                "Not: Karmaşık Word özellikleri (üst/alt bilgi, şekiller, "
                                "değişiklik izleme) korunmayabilir. Önemli belgelerin yedeğini al.")

    def closeEvent(self, e):
        if self.maybe_save():
            self.clear_recovery()
            e.accept()
        else:
            e.ignore()


def _log_crash(exc_type, exc, tb):
    """Pythonw'da hata penceresi görünmez; hatayı dosyaya yaz ve kutu göster."""
    text = "".join(traceback.format_exception(exc_type, exc, tb))
    log = os.path.join(data_dir(), "hata.txt")
    try:
        with open(log, "a", encoding="utf-8") as f:
            f.write(text + "\n")
    except Exception:
        pass
    try:
        QMessageBox.critical(None, APP, "Belgem bir hatayla karşılaştı:\n\n%s: %s\n\nAyrıntı dosyası:\n%s"
                             % (exc_type.__name__, exc, log))
    except Exception:
        pass


def main():
    sys.excepthook = _log_crash
    app = QApplication(sys.argv)
    app.setApplicationName(APP)
    app.setStyle("Fusion")
    path = sys.argv[1] if len(sys.argv) > 1 and os.path.exists(sys.argv[1]) else None
    w = Main(path)
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
