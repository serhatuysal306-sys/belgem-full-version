@echo off
setlocal
chcp 65001 >nul
title Belgem - Kur Beni
set "SRC=%~dp0"
set "APP=%LOCALAPPDATA%\Belgem\app"
echo.
echo   ====  Belgem kuruluyor  ====
echo.
echo   Dil secin / Choose language:
echo     1 - Turkce
echo     2 - English
echo     3 - Deutsch
echo     4 - Francais
echo     5 - Espanol
echo.
choice /C 12345 /N /M "  Numara / Number: "
set "LNG=tr"
if errorlevel 2 set "LNG=en"
if errorlevel 3 set "LNG=de"
if errorlevel 4 set "LNG=fr"
if errorlevel 5 set "LNG=es"
powershell -NoProfile -Command "$d=Join-Path $env:APPDATA 'Belgem'; New-Item -ItemType Directory -Force -Path $d | Out-Null; $p=Join-Path $d 'ayar.json'; $c=@{}; if(Test-Path $p){ (Get-Content $p -Raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $c[$_.Name]=$_.Value } }; $c['dil']='%LNG%'; $c | ConvertTo-Json | Set-Content -Encoding UTF8 $p"
echo.
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo   Python bulunamadi, otomatik kuruluyor...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  echo.
  echo   Python kuruldu. Bu pencereyi kapat ve "Kur Beni" dosyasina bir kez daha cift tikla.
  pause
  exit /b
)
if not exist "%SRC%belgem.py" (
  echo   belgem.py bulunamadi. Zip dosyasini once klasore cikar.
  pause
  exit /b 1
)
mkdir "%APP%" 2>nul
copy /y "%SRC%belgem.py" "%APP%\belgem.py" >nul
if not exist "%APP%\venv\Scripts\pythonw.exe" (
  echo   Ortam hazirlaniyor...
  %PY% -m venv "%APP%\venv" || goto :hata
)
echo   Gerekli bilesenler yukleniyor (sadece bu adimda internet gerekir)...
"%APP%\venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
"%APP%\venv\Scripts\python.exe" -m pip install --quiet PyQt6 python-docx || goto :hata
echo   Kisayollar olusturuluyor...
powershell -NoProfile -Command "$w=New-Object -ComObject WScript.Shell; foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){$s=$w.CreateShortcut($d+'\Belgem.lnk');$s.TargetPath='%APP%\venv\Scripts\pythonw.exe';$s.Arguments='\"%APP%\belgem.py\"';$s.WorkingDirectory='%APP%';$s.Save()}"
echo.
echo   Kurulum tamam! Belgem aciliyor...
start "" "%APP%\venv\Scripts\pythonw.exe" "%APP%\belgem.py"
timeout /t 3 >nul
exit /b
:hata
echo.
echo   Bir hata olustu. Internet baglantini kontrol edip tekrar dene.
pause
exit /b 1
